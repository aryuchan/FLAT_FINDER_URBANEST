// ff-auth.js — FlatFinder Auth Module
// Handles login / signup views and form events.
// Depends on: ff-core.js (API, Token, appState, apiFetch, escHtml, render,
//             renderNavBar, showToast, defaultRoute)
// ─────────────────────────────────────────────────────────────────

const Auth = {
  viewLogin(mode = "login") {
    const isLogin = mode === "login";
    return `
      <div class="auth-wrapper">
        <div class="auth-card">
          <div class="auth-logo">🏠</div>
          <h1 class="auth-title">FlatFinder</h1>
          <p class="auth-sub">${isLogin ? "Sign in to your account" : "Create a new account"}</p>

          <form id="auth-form" class="auth-form" novalidate autocomplete="on">
            ${
              !isLogin
                ? `
            <div class="form-group">
              <label class="form-label" for="auth-name">Full Name</label>
              <input class="form-input" id="auth-name" name="name" type="text"
                placeholder="Aarav Mehta" autocomplete="name"
                required minlength="2" maxlength="100" />
            </div>`
                : ""
            }

            <div class="form-group">
              <label class="form-label" for="auth-email">Email</label>
              <input class="form-input" id="auth-email" name="email" type="email"
                placeholder="you@example.com" autocomplete="email"
                required maxlength="254" />
            </div>

            <div class="form-group">
              <label class="form-label" for="auth-password">Password</label>
              <div class="input-wrap">
                <input class="form-input" id="auth-password" name="password" type="password"
                  placeholder="${isLogin ? "Your password" : "At least 8 characters"}"
                  autocomplete="${isLogin ? "current-password" : "new-password"}"
                  required minlength="${isLogin ? 1 : 8}" maxlength="128" />
                <button type="button" class="input-eye" id="toggle-password"
                  aria-label="Toggle password visibility">👁</button>
              </div>
            </div>

            ${
              !isLogin
                ? `
            <div class="form-group">
              <label class="form-label">Account Type</label>
              <div class="role-pills">
                <label class="role-pill">
                  <input type="radio" name="role" value="tenant" checked /> 🏠 Tenant
                </label>
                <label class="role-pill">
                  <input type="radio" name="role" value="owner" /> 🔑 Owner
                </label>
                <!-- Admin accounts are created by existing admins only, not via public signup -->
              </div>
            </div>`
                : ""
            }

            <div id="auth-error" class="form-error hidden" role="alert" aria-live="assertive"></div>

            <button class="btn btn--primary btn--full" type="submit" id="auth-submit">
              ${isLogin ? "Sign In" : "Create Account"}
            </button>
          </form>

          <p class="auth-switch">
            ${
              isLogin
                ? `Don't have an account? <a href="#/signup" data-route="/signup">Sign up free</a>`
                : `Already have an account? <a href="#/login" data-route="/login">Sign in</a>`
            }
          </p>
        </div>
      </div>`;
  },

  bindEvents(root) {
    root.querySelector("#toggle-password")?.addEventListener("click", () => {
      const input = root.querySelector("#auth-password");
      if (!input) return;
      const isHidden = input.type === "password";
      input.type = isHidden ? "text" : "password";
      const btn = root.querySelector("#toggle-password");
      if (btn) btn.setAttribute("aria-label", isHidden ? "Hide password" : "Show password");
    });

    const authForm = root.querySelector("#auth-form");
    if (!authForm) return;

    authForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const fd     = new FormData(authForm);
      const mode   = window.location.hash.includes("signup") ? "signup" : "login";
      const btn    = root.querySelector("#auth-submit");
      const errEl  = root.querySelector("#auth-error");

      const setError = (msg) => {
        if (!errEl) return;
        errEl.textContent = msg;
        errEl.classList.remove("hidden");
        errEl.focus();
      };
      const clearError = () => {
        if (!errEl) return;
        errEl.textContent = "";
        errEl.classList.add("hidden");
      };

      clearError();

      // ── Client-side validation ─────────────────────────────────
      const email    = fd.get("email")?.trim() ?? "";
      const password = fd.get("password") ?? "";
      const name     = fd.get("name")?.trim() ?? "";
      const role     = fd.get("role") || "tenant";

      if (!email || !password) {
        setError("Please fill in all required fields.");
        return;
      }

      // Basic email format check
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setError("Please enter a valid email address.");
        return;
      }

      if (mode === "signup") {
        if (!name || name.length < 2) {
          setError("Full name must be at least 2 characters.");
          return;
        }
        if (password.length < 8) {
          setError("Password must be at least 8 characters.");
          return;
        }
        // Prevent privilege escalation via UI tampering
        if (!["tenant", "owner"].includes(role)) {
          setError("Invalid account type selected.");
          return;
        }
      }
      // ──────────────────────────────────────────────────────────

      btn.disabled = true;
      btn.textContent = "Please wait…";

      const payload =
        mode === "signup"
          ? { name, email, password, role }
          : { email, password };

      const r = await apiFetch(`/api/${mode}`, { method: "POST", body: payload });

      btn.disabled = false;
      btn.textContent = mode === "login" ? "Sign In" : "Create Account";

      if (r.success) {
        // Support both { data: { user, token } } and { data: { ...user, token } }
        const user = r.data?.user ?? r.data;
        if (!user?.role) {
          setError("Unexpected server response. Please try again.");
          return;
        }
        appState.currentUser = user;
        renderNavBar();
        window.location.hash = defaultRoute();
        showToast(r.message || "Welcome!", "success");
      } else {
        const msg = r.message || "Something went wrong. Please try again.";
        setError(msg);
        showToast(msg, "error");
      }
    });
  },
};
