// db.js — Production Database Engine
import mysql from "mysql2/promise";
import logger from "./utils/logger.js";

// ─────────────────────────────────────────────────────────────────
// ⚠️  SECURITY: All credentials MUST be set via environment variables.
//     Create a .env file (never commit it) and load with dotenv:
//       DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
//
//     Fallback values below are for LOCAL DEVELOPMENT ONLY.
//     In production, ensure all env vars are set — no exceptions.
// ─────────────────────────────────────────────────────────────────
const dbConfig = {
  host:     process.env.DB_HOST     || "gateway01.ap-southeast-1.prod.aws.tidbcloud.com",
  port:     Number(process.env.DB_PORT) || 4000,
  user:     process.env.DB_USER     || (() => { throw new Error("DB_USER env var is required"); })(),
  password: process.env.DB_PASSWORD || (() => { throw new Error("DB_PASSWORD env var is required"); })(),
  database: process.env.DB_NAME     || "flatfinder",
  ssl: {
    rejectUnauthorized: true,           // Always validate TLS in production
    minVersion: "TLSv1.2",
  },
};

// Fail fast at startup if critical vars are missing
if (!process.env.DB_USER || !process.env.DB_PASSWORD) {
  logger.error(
    "❌ [DB_INIT] DB_USER and DB_PASSWORD environment variables are required. " +
    "Set them in your .env file or deployment environment. Never hardcode credentials."
  );
  process.exit(1);
}

logger.info(
  `[DB_INIT] Connecting to ${dbConfig.host}:${dbConfig.port} as ${dbConfig.user}`
);

// Connection Pool
export const pool = mysql.createPool({
  ...dbConfig,
  waitForConnections: true,
  connectionLimit:    20,
  maxIdle:            20,
  idleTimeout:        60000,
  queueLimit:         0,
  enableKeepAlive:    true,
  keepAliveInitialDelay: 0,
});

/**
 * Execute a parameterised query.
 * Always uses prepared statements — never interpolate user input into SQL.
 * @param {string}  sql    - Parameterised SQL string
 * @param {Array}   params - Bound parameters
 * @param {number}  retries - Retry count on transient failures (default 2)
 */
export async function query(sql, params = [], retries = 2) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const [results] = await pool.execute(sql, params);
      return results;
    } catch (err) {
      const isTransient =
        err.code === "PROTOCOL_CONNECTION_LOST" ||
        err.code === "ECONNRESET" ||
        err.code === "ETIMEDOUT";

      if (isTransient && attempt < retries) {
        logger.warn(`[DB] Transient error (attempt ${attempt + 1}): ${err.message}. Retrying…`);
        await new Promise((r) => setTimeout(r, 150 * (attempt + 1)));
        continue;
      }
      logger.error(`[DB_ERROR] SQL Error: ${err.message} | Code: ${err.code}`);
      throw err;
    }
  }
}

export async function queryOne(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0] || null;
}

/**
 * Wrap multiple queries in a transaction.
 * Automatically rolls back on error.
 * @param {Function} fn - Async function receiving a connection
 */
export async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

/**
 * Health check for startup verification
 */
export async function validateConnection() {
  try {
    logger.info(`Attempting connection to ${dbConfig.host}:${dbConfig.port}…`);
    const conn = await pool.getConnection();
    await conn.ping();
    conn.release();
    logger.info("✅ Database connection verified successfully.");
    return true;
  } catch (err) {
    logger.error(`❌ Database connection failed: ${err.message} (Code: ${err.code})`);
    return false;
  }
}
