// app.js — FlatFinder SPA Router & App Controller
// Handles URL hash changes, module initialization, and global events.
// Depends on: ff-core.js, ff-auth.js, ff-tenant.js, ff-owner.js, ff-admin.js
// ─────────────────────────────────────────────────────────────────

const App = {
  async init() {
    console.log("🚀 FlatFinder Initializing…");
    window.addEventListener("hashchange", () => this.router());
    window.addEventListener("unhandledrejection", (e) => {
      console.error("Unhandled Error:", e.reason);
      showToast("A network or system error occurred. Please refresh.", "error");
    });
    document.addEventListener("click", (e) => this.handleLinkClick(e));
    await this.checkAuth();
    this.router();

    // Hide loader
    const loader = document.querySelector("#app-loader");
    if (loader) loader.classList.add("hidden-loader");
  },

  async checkAuth() {
    if (!Token.get()) return;
    const r = await apiFetch("/api/me");
    if (r.success && r.data?.role) {
      appState.currentUser = r.data;
      renderNavBar();
    } else {
      // Token invalid or expired — clear silently
      Token.clear();
      appState.currentUser = null;
    }
  },

  handleLinkClick(e) {
    // Handle data-route links
    const link = e.target.closest("a[data-route]");
    if (link) {
      e.preventDefault();
      const route = link.getAttribute("data-route");
      // route values are already without "#" (e.g. "/tenant/dashboard")
      window.location.hash = route;
    }

    // Handle logout button (delegated, works across re-renders)
    if (e.target.id === "logout-btn" || e.target.closest("#logout-btn")) {
      Token.clear();
      appState.currentUser = null;
      appState.flats       = [];
      appState.bookings    = [];
      appState.users       = [];
      appState.listings    = [];
      appState._selectedFlat = null;
      window.location.hash = "/login";
      renderNavBar();
      showToast("Logged out successfully.", "info");
    }
  },

  async router() {
    const hash = window.location.hash || "#/";
    // hash.slice(1) strips the leading "#" — e.g. "#/login" → "/login"
    const path = hash.slice(1) || "/";
    const u    = appState.currentUser;

    // ── Public Routes ──────────────────────────────────────────
    if (path === "/login")  return render(Auth.viewLogin("login"));
    if (path === "/signup") return render(Auth.viewLogin("signup"));

    // ── Guard: Auth Required ───────────────────────────────────
    if (!u) {
      window.location.hash = "/login";
      return;
    }

    // ── Guard: Role-based Index Redirect ───────────────────────
    if (path === "/") {
      window.location.hash = defaultRoute();
      return;
    }

    // ── TENANT ROUTES ──────────────────────────────────────────
    if (u.role === "tenant") {
      // Dashboard
      if (path === "/tenant/dashboard") {
        const [br, fr] = await Promise.all([
          apiFetch("/api/bookings"),
          apiFetch("/api/flats"),
        ]);
        if (br.success) appState.bookings = br.data ?? [];
        if (fr.success) appState.flats    = fr.data ?? [];
        return render(Tenant.viewDashboard());
      }

      // Search
      if (path === "/tenant/search") {
        const r = await apiFetch("/api/flats");
        if (r.success) appState.flats = r.data ?? [];
        return render(Tenant.viewSearch());
      }

      // My Bookings (dedicated page)
      if (path === "/tenant/bookings") {
        const r = await apiFetch("/api/bookings");
        if (r.success) appState.bookings = r.data ?? [];
        // Use dedicated view if module provides it, else fall back to inline table
        return render(
          typeof Tenant.viewBookings === "function"
            ? Tenant.viewBookings()
            : _fallbackBookingsView(appState.bookings)
        );
      }

      // Flat Details
      if (path.startsWith("/tenant/flat/")) {
        const id = path.split("/")[3];
        if (!id) return render(_notFoundView("Invalid flat ID."));
        const r = await apiFetch(`/api/flats/${id}`);
        if (r.success) {
          appState._selectedFlat = r.data;
          return render(Tenant.viewFlatDetails(r.data));
        }
        return render(_notFoundView(r.message || "Could not load flat details."));
      }

      // Booking Form
      if (path.startsWith("/tenant/booking/")) {
        const id = path.split("/")[3];
        if (!id) return render(_notFoundView("Invalid booking ID."));
        const r = await apiFetch(`/api/flats/${id}`);
        if (r.success) {
          appState._selectedFlat = r.data;
          return render(Tenant.viewBooking(r.data));
        }
        return render(_notFoundView("This flat is no longer available for booking."));
      }
    }

    // ── OWNER ROUTES ───────────────────────────────────────────
    if (u.role === "owner") {
      if (path === "/owner/dashboard") {
        const [lr, br] = await Promise.all([
          apiFetch("/api/listings"),
          apiFetch("/api/bookings"),
        ]);
        if (lr.success) appState.listings = lr.data ?? [];
        if (br.success) appState.bookings = br.data ?? [];
        return render(Owner.viewDashboard());
      }
      if (path === "/owner/add-flat")  return render(Owner.viewAddFlat());
      if (path === "/owner/profile")   return render(Owner.viewProfile());
    }

    // ── ADMIN ROUTES ───────────────────────────────────────────
    if (u.role === "admin") {
      if (path === "/admin/dashboard") {
        const [ur, fr, br, lr] = await Promise.all([
          apiFetch("/api/users"),
          apiFetch("/api/flats"),
          apiFetch("/api/bookings"),
          apiFetch("/api/listings"),
        ]);
        if (ur.success) appState.users    = ur.data ?? [];
        if (fr.success) appState.flats    = fr.data ?? [];
        if (br.success) appState.bookings = br.data ?? [];
        if (lr.success) appState.listings = lr.data ?? [];
        return render(Admin.viewDashboard());
      }
      if (path === "/admin/approvals") {
        const r = await apiFetch("/api/listings");
        if (r.success) appState.listings = r.data ?? [];
        return render(Admin.viewApprovals());
      }
      if (path === "/admin/users") {
        const r = await apiFetch("/api/users");
        if (r.success) appState.users = r.data ?? [];
        return render(Admin.viewUsers());
      }
    }

    // ── Fallback: 404 / Access Denied ──────────────────────────
    render(`
      <div class="container page-content">
        <div class="empty-state">
          <p style="font-size:3rem">🔒</p>
          <h3>Access Denied / Not Found</h3>
          <p class="text-muted">
            You don't have permission to view this page, or it doesn't exist.
          </p>
          <a class="btn btn--primary" href="#" data-route="/">Go to Dashboard</a>
        </div>
      </div>`);
  },
};

// ── HELPERS ──────────────────────────────────────────────────────
function defaultRoute() {
  const u = appState.currentUser;
  if (!u) return "/login";
  if (u.role === "admin") return "/admin/dashboard";
  if (u.role === "owner") return "/owner/dashboard";
  return "/tenant/dashboard";
}

function _notFoundView(message) {
  return `
    <div class="container page-content">
      <div class="empty-state">
        <p style="font-size:2.5rem">❌</p>
        <h3>Not Found</h3>
        <p class="text-muted">${escHtml(message)}</p>
        <a class="btn btn--primary mt-md" href="#" data-route="/">Back to Dashboard</a>
      </div>
    </div>`;
}

// Inline fallback for "My Bookings" if ff-tenant.js doesn't expose viewBookings()
function _fallbackBookingsView(bookings) {
  if (!bookings.length) {
    return `
      <div class="container page-content">
        <div class="page-header"><h2>My Bookings</h2></div>
        <div class="empty-state">
          <p style="font-size:2.5rem">📋</p>
          <h3>No Bookings Yet</h3>
          <p class="text-muted">You haven't made any bookings. Start searching for flats!</p>
          <a class="btn btn--primary mt-md" href="#/tenant/search" data-route="/tenant/search">
            🔍 Search Flats
          </a>
        </div>
      </div>`;
  }

  const rows = bookings
    .map(
      (b) => `
      <tr>
        <td><strong>${escHtml(b.flat_title || "Flat")}</strong>
            <br><small class="text-muted">📍 ${escHtml(b.city || "")}</small></td>
        <td>₹${Number(b.rent || 0).toLocaleString("en-IN")}</td>
        <td>${b.checkin_date ? b.checkin_date.slice(0, 10) : "—"}</td>
        <td>
          <span class="badge badge--${
            b.status === "approved" ? "success"
            : b.status === "rejected" ? "danger"
            : "warning"
          }">${escHtml(b.status || "pending")}</span>
        </td>
      </tr>`,
    )
    .join("");

  return `
    <div class="container page-content">
      <div class="page-header"><h2>My Bookings</h2></div>
      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead>
              <tr>
                <th>Flat</th>
                <th>Rent</th>
                <th>Check-In</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>
    </div>`;
}

function bindEvents() {
  const root = document.getElementById("app-root");
  if (!root) return;
  const path = window.location.hash.slice(1) || "/";

  if (path.includes("login") || path.includes("signup")) Auth.bindEvents(root);
  if (path.startsWith("/tenant")) Tenant.bindEvents(root);
  if (path.startsWith("/owner"))  Owner.bindEvents(root);
  if (path.startsWith("/admin"))  Admin.bindEvents(root);
}

// ── BOOTSTRAP ────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => App.init());
