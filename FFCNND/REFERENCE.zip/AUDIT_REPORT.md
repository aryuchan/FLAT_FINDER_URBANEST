# FlatFinder — Code Audit & Fix Report

## Summary

Full review of all provided source files against real-world production standards.
6 files fixed with surgical, minimum-change patches. Issues classified by severity.

---

## 🔴 CRITICAL (Security / Data-loss)

### 1. `db.js` — Hardcoded Database Credentials *(Fixed)*

**Problem:** Database host, username, and password were hardcoded in plain text inside the source file. Anyone with access to the repo (public or private leak) has full database access. The comment "As requested, environment variables are bypassed to ensure stability" makes this actively worse — stability arguments do not override credential security.

**Impact:** Complete database compromise, data theft, ransom attack.

**Fix applied:**
- All credentials now read from `process.env.DB_USER`, `process.env.DB_PASSWORD`, etc.
- Server exits immediately (`process.exit(1)`) if critical vars are missing, preventing silent misconfiguration.
- `rejectUnauthorized` set to `true` for TLS (was `false`, allowing MITM attacks).
- Added a `withTransaction()` helper for atomic multi-step operations.
- Added retry logic for transient connection errors (was disabled "for debugging" — unacceptable in production).

**Action required:** Create a `.env` file (never commit it), add `.env` to `.gitignore`, set `DB_USER` and `DB_PASSWORD`. In production, use your platform's secret manager (Railway secrets, AWS Parameter Store, etc.).

---

### 2. `ff-auth.js` — Admin Role Available at Public Signup *(Fixed)*

**Problem:** The signup form included a third radio option: `👑 Admin`. Any anonymous user could self-register with admin privileges, gaining full access to user management, listing approvals, and all platform data.

**Impact:** Immediate full platform takeover by any user.

**Fix applied:**
- Removed the Admin radio option from the public signup form.
- Added server-side enforcement comment — the server MUST also reject `role=admin` from unauthenticated requests.
- Added a client-side guard: if the submitted role is not `tenant` or `owner`, the form rejects it before the API call.
- Admin accounts should only be created by existing admins (via a separate, protected admin-only route on the server).

---

## 🟠 HIGH (Broken Functionality)

### 3. `app.js` — Missing `/tenant/bookings` Route *(Fixed)*

**Problem:** The nav bar for tenants included a "📋 My Bookings" link pointing to `/tenant/bookings`. The router had no handler for this path. Clicking the link showed the "🔒 Access Denied / Not Found" screen.

**Impact:** Core tenant feature completely broken.

**Fix applied:**
- Added `/tenant/bookings` route handler. Calls `Tenant.viewBookings()` if defined in `ff-tenant.js`; falls back to a fully functional inline table view (`_fallbackBookingsView`) that displays booking status badges, flat name, city, rent, and check-in date.
- The fallback is self-contained so the app works even if `ff-tenant.js` doesn't expose `viewBookings`.

---

### 4. `app.js` — Logout Didn't Clear State *(Fixed)*

**Problem:** On logout, only `appState.currentUser` was cleared. All other state (`flats`, `bookings`, `users`, `listings`, `_selectedFlat`) remained in memory. If a new user logged in during the same session, they could see the previous user's data before the next API call.

**Fix applied:** Logout now resets the entire `appState` object to empty arrays/null.

---

### 5. `app.js` — `checkAuth` Didn't Validate User Shape *(Fixed)*

**Problem:** `if (r.success) appState.currentUser = r.data` — if `r.data` was malformed (e.g., missing `role`), the router would fail silently with confusing behaviour.

**Fix applied:** Checks `r.data?.role` exists before accepting the user object.

---

## 🟡 MEDIUM (Bugs / UX)

### 6. `ff-admin.js` — Filter State Lost After Approve/Reject *(Fixed)*

**Problem:** After approving or rejecting a listing, the entire table re-rendered via `render(Admin.viewApprovals())`, which reset the status filter dropdown to "All Status" even if the admin had filtered to "Pending".

**Fix applied:**
- `viewApprovals` now accepts an `activeFilter` parameter and pre-selects the correct `<option>` via a `selected` attribute.
- After approve/reject actions, the current filter value is read before re-rendering, and the filtered list is applied to just the `<tbody>` (no full page re-render), preserving scroll position and filter state.

### 7. `ff-admin.js` — Double `Admin.` Reference Issue *(Fixed)*

**Problem:** Inside `bindEvents`, calling `Admin.viewApprovals()` and `Admin.viewUsers()` via `this` inside event listener callbacks can lose context. `_refilterUsers` was also defined inside `bindEvents` as a local function, making it inaccessible after a re-render triggered re-registration.

**Fix applied:** Extracted `_refilterUsers` as a module-level function. Used `Admin._approvalsRows()` directly (static, no `this` binding issues).

### 8. `ff-core.js` — AbortError Not Distinguished from Network Error *(Fixed)*

**Problem:** A request timing out (AbortController) threw the same generic "Cannot reach server" message as a DNS failure, making it impossible for users to know whether to wait or reload.

**Fix applied:** `err.name === "AbortError"` is now caught specifically with the message: "Request timed out. Check your connection and try again."

### 9. `ff-core.js` — Auto-Logout on 401 Not Implemented *(Fixed)*

**Problem:** When a JWT expired mid-session, API calls returned 401 but the user stayed on the page with a broken UI (data wouldn't load, errors appeared). No automatic redirect to login.

**Fix applied:** `apiFetch` now checks for HTTP 401, clears the token, resets `currentUser`, and redirects to `/login` automatically.

### 10. `ff-core.js` — Modal Not Accessible *(Fixed)*

**Problem:** `showModal` appended content but didn't focus the modal, didn't handle `Escape` key, and didn't update `aria-hidden` on the container.

**Fix applied:** Modal now sets `aria-hidden="false"` on open, auto-focuses first focusable element, and closes on Escape key.

### 11. `ff-core.js` — `render()` Didn't Scroll to Top *(Fixed)*

**Problem:** Navigating between pages left the scroll position wherever it was. Clicking "My Bookings" from the bottom of the dashboard left the user looking at the bottom of the bookings page.

**Fix applied:** `render()` calls `window.scrollTo({ top: 0, behavior: "instant" })` before injecting HTML.

### 12. `ff-auth.js` — Password Minimum Too Low for Signup *(Fixed)*

**Problem:** `minlength="6"` on the signup password field. 6 characters is below current NIST and OWASP minimums.

**Fix applied:** Minimum raised to 8 characters on signup. Login retains no client-side minimum (to avoid locking out existing users while migrating).

### 13. `ff-auth.js` — Eye Toggle Button Missing Aria State Update *(Fixed)*

**Problem:** Clicking 👁 toggled the input type but the `aria-label` stayed "Toggle password visibility" regardless of current state.

**Fix applied:** `aria-label` now dynamically updates to "Hide password" / "Show password".

### 14. `ff-auth.js` — User Shape Assumed After Login *(Fixed)*

**Problem:** `appState.currentUser = r.data.user` — if the server returns `{ data: { ...userFields, token } }` (flat user object, not nested under `user`), this would be `undefined`.

**Fix applied:** `const user = r.data?.user ?? r.data` handles both response shapes. Added a guard: if `user.role` is missing, an error is shown instead of proceeding with a broken session.

---

## 🔵 LOW (Code Quality / Maintainability)

### 15. `app.js` — Route Handlers Mixed Role Check and Data Fetch

Each route checked `u.role === "X"` inline before grouping. Moving role checks to the outer `if (u.role === "tenant")` block makes the code cleaner and makes "wrong role" misses fall through to the 404 handler correctly.

**Fix applied:** Routes now grouped under `if (u.role === "tenant") { ... }` etc., eliminating repeated `&& u.role === "tenant"` conditions.

### 16. `db.js` — Retries Disabled "for Debugging"

**Problem:** Comment said retries were disabled "for debugging as requested." Disabling retries in production causes transient network blips to surface as hard failures.

**Fix applied:** Retries re-enabled with 2 attempts, exponential back-off (150ms, 300ms), and only for known transient error codes (`ECONNRESET`, `ETIMEDOUT`, `PROTOCOL_CONNECTION_LOST`).

### 17. General — `r.data ?? []` Pattern Missing

Several places did `if (r.success) appState.flats = r.data` — if `r.data` was `null` (server bug), the app would crash iterating over it. All state assignments now use `r.data ?? []`.

---

## ⚠️ Issues Outside Provided Files

These require changes to `server.js` (not provided):

| Issue | Severity | Fix Needed in server.js |
|---|---|---|
| Server must reject `role=admin` at signup | 🔴 Critical | Validate `role` in `/api/signup` handler |
| No rate limiting on `/api/login` | 🟠 High | Add express-rate-limit to auth routes |
| JWT secret should be in env var | 🔴 Critical | `process.env.JWT_SECRET` (never hardcode) |
| Passwords must be bcrypt-hashed | 🔴 Critical | Use `bcrypt.hash()` on signup, `bcrypt.compare()` on login |
| SQL injection via unsanitised params | 🔴 Critical | Always use prepared statements (parameterised queries) |
| CORS should whitelist known origins only | 🟠 High | `cors({ origin: process.env.ALLOWED_ORIGINS })` |

---

## Files Changed

| File | Status | Key Changes |
|---|---|---|
| `db.js` | ✅ Fixed | Env vars, TLS fix, retry logic, `withTransaction` |
| `ff-core.js` | ✅ Fixed | AbortError, 401 auto-logout, modal a11y, scroll reset |
| `ff-auth.js` | ✅ Fixed | Remove admin signup, validation, password min, aria |
| `app.js` | ✅ Fixed | `/tenant/bookings` route, state reset on logout, role grouping |
| `ff-admin.js` | ✅ Fixed | Filter persistence, `_refilterUsers` extraction |
| `index.html` | ✅ Fixed | Loader aria attributes |
| `ff-tenant.js` | ⚠️ Not provided — review separately |
| `ff-owner.js` | ⚠️ Not provided — review separately |
| `server.js` | ⚠️ Not provided — review separately (critical items above) |
