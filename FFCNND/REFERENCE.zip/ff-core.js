// ff-core.js — FlatFinder Core Module
// Config · Token · State · API · Security · Render · Nav · UI Utilities
// Loaded first. All other modules depend on globals exposed here.
// ─────────────────────────────────────────────────────────────────

// ── CONFIG ──────────────────────────────────────────────────────
// Empty string = same origin (recommended for production).
// For dev with a separate API server set to e.g. "http://localhost:3000"
const API = "";

const REQUEST_TIMEOUT_MS = 20000; // 20 s — enough for slow mobile connections

// ── TOKEN ────────────────────────────────────────────────────────
// ⚠️  localStorage is readable by any JS on the page (XSS risk).
// If your server supports it, prefer httpOnly cookies and remove
// the Authorization header from apiFetch entirely.
const Token = {
  get:   ()  => localStorage.getItem("ff_jwt"),
  save:  (t) => { if (t && typeof t === "string") localStorage.setItem("ff_jwt", t); },
  clear: ()  => localStorage.removeItem("ff_jwt"),
};

// ── GLOBAL STATE ─────────────────────────────────────────────────
const appState = {
  currentUser: null,
  flats:       [],
  bookings:    [],
  users:       [],
  listings:    [],
  _selectedFlat: null,
};

// ── API CLIENT ───────────────────────────────────────────────────
async function apiFetch(path, options = {}) {
  const controller = new AbortController();
  const timeoutId  = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const token      = Token.get();
    const isFormData = options.body instanceof FormData;

    const init = {
      method:      options.method || "GET",
      credentials: "include",
      signal:      controller.signal,
      headers: {
        ...(token       ? { Authorization: `Bearer ${token}` } : {}),
        ...(isFormData  ? {} : { "Content-Type": "application/json" }),
        ...(options.headers || {}),
      },
    };

    if (options.body) {
      init.body = isFormData
        ? options.body
        : typeof options.body === "object"
          ? JSON.stringify(options.body)
          : options.body;
    }

    const res = await fetch(`${API}${path}`, init);
    clearTimeout(timeoutId);

    const ct = res.headers.get("content-type") || "";
    if (!ct.includes("application/json")) {
      // Surface HTTP status codes so callers can react appropriately
      return {
        success: false,
        data: null,
        message: res.status === 401
          ? "Session expired. Please log in again."
          : res.status === 403
          ? "You do not have permission to do that."
          : res.status === 429
          ? "Too many requests. Please slow down and try again."
          : `Server error (${res.status}). Please try again later.`,
      };
    }

    const json = await res.json();

    // Persist token whenever the server returns a fresh one
    if (json?.data?.token) Token.save(json.data.token);

    // Auto-logout on 401 (expired/invalid token)
    if (res.status === 401) {
      Token.clear();
      appState.currentUser = null;
      renderNavBar();
      if (window.location.hash !== "#/login") {
        window.location.hash = "/login";
      }
    }

    return json;
  } catch (err) {
    clearTimeout(timeoutId);

    if (err.name === "AbortError") {
      return {
        success: false,
        data: null,
        message: "Request timed out. Check your connection and try again.",
      };
    }

    console.error("[apiFetch]", path, err);
    return {
      success: false,
      data: null,
      message: "Cannot reach server. Is the server running?",
    };
  }
}

// ── SECURITY ─────────────────────────────────────────────────────
function escHtml(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// ── RENDER ───────────────────────────────────────────────────────
function render(html) {
  const root = document.getElementById("app-root");
  if (!root) return;
  root.innerHTML = html;
  // Scroll to top on every "page" change
  window.scrollTo({ top: 0, behavior: "instant" });
  bindEvents();
}

function renderNavBar() {
  const nav = document.getElementById("app-nav");
  if (!nav) return;
  const u = appState.currentUser;
  if (!u) {
    nav.innerHTML = "";
    return;
  }

  const roleLinks = {
    tenant: [
      { label: "🏠 Dashboard",   route: "/tenant/dashboard" },
      { label: "🔍 Search Flats", route: "/tenant/search"    },
      { label: "📋 My Bookings",  route: "/tenant/bookings"  },
    ],
    owner: [
      { label: "🏠 Dashboard", route: "/owner/dashboard" },
      { label: "➕ Add Flat",  route: "/owner/add-flat"   },
      { label: "👤 My Profile", route: "/owner/profile"   },
    ],
    admin: [
      { label: "🏠 Dashboard", route: "/admin/dashboard" },
      { label: "✅ Approvals",  route: "/admin/approvals" },
      { label: "👥 Users",      route: "/admin/users"     },
    ],
  };

  const badgeClass = {
    admin:  "badge--danger",
    owner:  "badge--warning",
    tenant: "badge--success",
  };

  const links = (roleLinks[u.role] || [])
    .map(
      (l) =>
        `<a class="nav__link" href="#${l.route}" data-route="${l.route}">${l.label}</a>`,
    )
    .join("");

  nav.innerHTML = `
    <div class="nav__inner container">
      <a class="nav__brand" href="#" data-route="/">🏠 FlatFinder</a>
      <div class="nav__links">${links}</div>
      <div class="nav__user">
        <span class="nav__name">${escHtml(u.name)}</span>
        <span class="badge ${badgeClass[u.role] || "badge--neutral"}">${escHtml(u.role)}</span>
        <button class="btn btn--secondary btn--sm" id="logout-btn">Logout</button>
      </div>
    </div>`;
}

// ── UI UTILITIES ──────────────────────────────────────────────────
function showToast(message, type = "info") {
  const toast = document.getElementById("app-toast");
  if (!toast) return;
  const cls = {
    success: "toast--success",
    error:   "toast--error",
    warning: "toast--warning",
    info:    "toast--info",
  };
  const div = document.createElement("div");
  div.className = `toast ${cls[type] || "toast--info"}`;
  div.innerHTML = `
    <span class="toast__message">${escHtml(message)}</span>
    <button class="toast__close" onclick="this.parentElement.remove()" aria-label="Dismiss">×</button>`;
  toast.appendChild(div);
  setTimeout(() => div.remove(), 4500);
}

function showModal(html) {
  closeModal();
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.innerHTML = `
    <div class="modal-box" role="dialog" aria-modal="true">
      <button class="modal__close" onclick="closeModal()" aria-label="Close modal">×</button>
      ${html}
    </div>`;
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) closeModal();
  });
  // Trap focus inside modal
  overlay.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeModal();
  });
  const modalEl = document.getElementById("app-modal");
  if (modalEl) {
    modalEl.appendChild(overlay);
    modalEl.setAttribute("aria-hidden", "false");
    // Focus first focusable element
    const firstFocusable = overlay.querySelector("button, [href], input, select, textarea");
    firstFocusable?.focus();
  }
}

function closeModal() {
  const modalEl = document.getElementById("app-modal");
  modalEl?.querySelector(".modal-overlay")?.remove();
  modalEl?.setAttribute("aria-hidden", "true");
}
